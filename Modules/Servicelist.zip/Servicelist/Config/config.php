<?php

return [
    'name' => 'Servicelist',
];
