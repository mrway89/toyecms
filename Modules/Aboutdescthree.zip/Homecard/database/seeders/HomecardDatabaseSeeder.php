<?php

namespace Modules\Homecard\database\seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Modules\Tag\Entities\Homecard;

class HomecardDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Disable foreign key checks!
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        /*
         * Homecards Seed
         * ------------------
         */

        // DB::table('homecards')->truncate();
        // echo "Truncate: homecards \n";

        Homecard::factory()->count(20)->create();
        $rows = Homecard::all();
        echo " Insert: homecards \n\n";

        // Enable foreign key checks!
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}
