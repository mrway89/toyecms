<?php

return [
    'name' => 'Bgimage',
];
