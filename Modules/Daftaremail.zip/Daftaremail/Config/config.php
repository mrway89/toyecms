<?php

return [
    'name' => 'Daftaremail',
];
